<?php if(!defined("a")) exit("Error 001");
//本文件请勿修改，这些只会出现在后台底部，访客的看不到的，修改肯定会导致部分功能出现错误
?>
<div id="footer">Copyright &copy; <span style="color:#FF5200">HuoDuan</span><span style="color:#0065FF">.com</span> , Powered by <a href="http://www.huoduan.com" target="_blank">火端网络</a></div>