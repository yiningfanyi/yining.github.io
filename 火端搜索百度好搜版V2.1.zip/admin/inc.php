<?php if(!defined("a")) exit("Error 001");?>
<title>搜索管理后台 - Powered by huoduan.com</title>
<meta name="keywords" content="搜索程序" />
<meta name="description" content="本程序由火端网络开发设计，http://www.huoduan.com ，唯一销售客服QQ号码：909516866" />
<link href="images/huoduan.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/x-icon" href="./../favicon.ico">