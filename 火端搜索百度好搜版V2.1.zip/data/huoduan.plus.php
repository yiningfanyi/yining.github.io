<?php
 $plus =  array (
  'user' => 
  array (
    0 => '2',
    1 => '1',
    2 => '1',
    3 => '2',
    4 => '2',
    5 => '1',
    6 => '2',
    7 => '1',
  ),
  'type' => 
  array (
    0 => '2',
    1 => '2',
    2 => '3',
    3 => '2',
    4 => '1',
    5 => '3',
    6 => '2',
  ),
  'key' => 
  array (
    0 => '天气',
    1 => '源码|仿站|网站建设|PHP',
    2 => '/^(([^-][a-z0-9A-Z-_]+\\.)*)[^-][a-z0-9A-Z-_]+(\\.[a-zA-Z]{2,4}){1,2}$/',
    3 => '万年历|日历|农历',
    4 => '计算器',
    5 => '/^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$/',
    6 => '短网址|短链接|网址缩短',
  ),
  'num' => 
  array (
    0 => '1',
    1 => '2',
    2 => '1',
    3 => '1',
    4 => '1',
    5 => '1',
    6 => '1',
  ),
  'value' => 
  array (
    0 => '<div id="plus"><iframe name="weather_inc" src="http://i.tianqi.com/index.php?c=code&id=2&num=3" width="440" height="70" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div>',
    1 => '<div class="g"><h2><a href="http://www.huoduan.com" target="_blank" class="s">火端网络 - 专注于网站建设,模板制作,源码出售,仿站,网站二次开发!</a>  <b style="background-color:#2b99ff; color:#FFFFFF;font-size:14px;">官网</b></h2><div class="std">火端网络(www.huoduan.com),专注于网站建设,手机网站制作,网站模板设计,博客主题设计,源码出售,仿站,Wordpress博客搭建,网站二次开发,PHP程序开发,域名注册,主机...</div><span class="a">www.huoduan.com/</span></div>  ',
    2 => '<div id="plus">您是不是要访问： <a href="http://{$q}" target="_blank">http://{$q}</a></div> <!--这里判断是否是域名-->',
    3 => '<div id="plus"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="540" height="470">
          <param name="movie" value="http://apps3.bdimg.com/store/static/kvt/e734b907d9a5bb905e3722fcfb85c9a2.swf">
          <param name="quality" value="high">
          <embed src="http://apps3.bdimg.com/store/static/kvt/e734b907d9a5bb905e3722fcfb85c9a2.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="540" height="470">
        </object></div>',
    4 => '<div id="plus"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="540" height="520">
          <param name="movie" value="http://apps2.bdimg.com/store/static/kvt/3e9b470e8b9fceaa66d46a935b45518e.swf">
          <param name="quality" value="high">
          <embed src="http://apps2.bdimg.com/store/static/kvt/3e9b470e8b9fceaa66d46a935b45518e.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="540" height="520">
        </object></div>',
    5 => '<div id="plus"><script src=" http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js&ip={$q}" type="text/javascript"></script>
IP：{$q}的归属地为：<span class="green">
<script type="text/javascript">
document.write(remote_ip_info.country);
document.write(remote_ip_info.province);
document.write(remote_ip_info.city);
document.write(remote_ip_info.district);
document.write(remote_ip_info.isp);
document.write(remote_ip_info.type);
document.write(remote_ip_info.desc); 
</script></span></div>',
    6 => '<div id="plus"><iframe src="http://myapp.alifeifei.net/app/urlzip/box/?desktop=1&f=s" width="540" height="210" scrolling="no" frameborder="0"></iframe></div>',
  ),
  'value1' => 
  array (
    0 => '',
    1 => '火端网络 <a href="http://www.huoduan.com" target="_blank">http://www.huoduan.com</a>

<div class="cl10"></div>',
    2 => '',
    3 => '',
    4 => '',
    5 => '',
    6 => '',
  ),
);
?>