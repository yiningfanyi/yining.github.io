<?php
 $seturl =  array (
  'type' => 
  array (
    0 => '2',
    1 => '2',
    2 => '1',
  ),
  'oldurl' => 
  array (
    0 => '.jd.com',
    1 => '.jumei.com',
    2 => 'www.taobao.com',
  ),
  'newurl' => 
  array (
    0 => 'http://c.duomai.com/track.php?site_id=52589&aid=61&euid=hdso&t={en_url}',
    1 => 'http://c.duomai.com/track.php?site_id=52589&aid=97&euid=hdso&t={en_url}',
    2 => 'http://ai.taobao.com?pid=mm_15053590_11620972_41468269',
  ),
);
?>