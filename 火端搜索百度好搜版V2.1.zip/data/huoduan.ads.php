<?php
 $ads =  array (
  'search' => '3',
  'mobile_search' => '3',
);
?>